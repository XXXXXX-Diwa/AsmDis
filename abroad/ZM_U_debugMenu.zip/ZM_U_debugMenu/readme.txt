Metroid Zero Mission Debug Menu Mod

--------
Overview
--------
This is a mod that replaces the status screen with a debug menu when you pause the game. The debug menu allows you to give yourself items, download area maps, save the game, modify the in-game time, switch the language, change the difficulty, and set events. This debug menu is present in a beta version of the game, but nearly all of the debug menu's code and data were removed in the official release. 

To apply the mod, use Lunar IPS to apply the ZM_U_debugMenu.ips file to a North American (U) version of a Metroid Zero Mission ROM.

The asm source files are also included for those who wish to customize the code or use the files in a project. In particular, there's an option to use the original Japanese text for the menu items.

--------------------
Using the Debug Menu
--------------------
Access the debug menu by pausing the game and pressing R. If you hold Select while loading the pause screen, the status screen will be normal until you load the pause screen again. Otherwise, if you hold Select while loading the status screen, the status screen will be normal until you load the status screen again. If you hold Select + L while loading the pause screen, the map for the current area will download.

The top of the debug menu tells you the current area, room number, and door number.

The top left section of the debug menu allows you to toggle abilities on and off. Highlighting the left square will give you the item, and highlighting the name will activate the item.

The "STATUS" section allows you to set whether you have the normal suit, the fully powered suit, or no suit.

The top right section allows you to set the current and maximum amount of energy, missiles, super missiles, and power bombs.

"SEVENT" doesn't do anything. This is likely a leftover from Metroid Fusion's debug menu, where this value was actually used.

"EQUIP:TANK" allows you to quickly add or remove all items. Selecting "EQUIP" and pressing R or Start will give you all the abilities your current suit can have. Pressing L or Select will remove every ability. Selecting "TANK" and pressing R or Start will give you the maximum possible amount of energy, missiles, super missiles, and power bombs. Pressing L or Select will set them to their default starting values.

The "GET_MAP" section allows you to toggle area maps as downloaded or not.

Under "EQUIP:TANK", the current save file is highlighted, and selecting "SAVE" will save the game.

The "TIME" section allows you to set the in-game hours, minutes, and seconds.

The "LANG" section lets you change the language between Japanese, Hiragana (Japanese without kanji), and English. There are other language options to choose from, but they don't actually exist in this version of the game.

The "LEVEL" section lets you change the difficulty between easy, normal, and hard.

Pressing Select on the debug menu will bring up the event list. Events that have been set will be highlighted. Any event can be toggled on or off. Pressing Left or Right will scroll the list by 10 events.

--------
asm Info
--------
If you'd prefer to use the original Japanese event names, you can switch the text used in asm/data/new_data.asm. You can also use the original text for a few words on the debug menu ("ROOM", "DOOR", and "GRIP") by removing the import at the end of asm/ZM_U_debugMenu.asm.

Functions starting with "sub" are functions needed for the debug menu, but their exact purpose is unknown. Similarly, addresses starting with "unk" are RAM or ROM addresses with an unknown purpose. Knowing exactly what they do isn't necessary to make the debug menu to work, but feel free to investigate their purpose yourself.

For those curious about code structure, here is the call stack for all of the new and modified functions:

sub_806ABE0
|__ sub_806C9F4
    |__ sub_806CA30
MainLoopForPauseScreen
|__ OnDebugMenu
|   |__ OnMainDebugMenu
|   |   |__ sub_8078890
|   |   |__ DebugMenuToggleEquipment
|   |   |__ UpdateMapOverlay
|   |   |__ DebugMenuEnergyAndAmmo
|   |   |__ DebugMenuDrawAffectedRegions
|   |   |   |__ DebugMenuDrawAbilityRegion
|   |   |   |__ DebugMenuDrawEnergyAndAmmoRegion
|   |   |   |__ DebugMenuDrawEnergyAndAmmoNum
|   |   |__ DebugMenuEquipTank
|   |   |__ UpdateEventList
|   |   |   |__ DrawEventName
|   |   |__ ActivateAllAbilities
|   |__ OnDebugEventList
|   |__ HandleDebugEventInput
|__ LoadStatusScreen
|   |__ sub_8071F58
|   |   |__ sub_807180C
|   |__ sub_8071F7C
|__ CloseStatusScreen
