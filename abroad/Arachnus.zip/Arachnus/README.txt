Contents:
1)Files
2)How To Use
3)Notes
4)Credits

1). FILES
"MainAI.asm" is the arachnus primary AI. "BodyParts.asm" contains AI for it's many bodily secondary sprites.
"Projeciles.asm" contains the AI for the projectiles it shoots. There are some comments provided in for reference. 
Any major changes will likely break the AI. Know what you are doing before modifying.

"Arachnus.asm" is the file that is used to compile everything. The file also includes weakness and drop values 
for each sprite. 

"palette.pal" Contains the sprite palettes.

"graphics.gfx.lz" Is the graphics used for everything.

"tables.asm" is needed for tables arachnus uses that don't exist in ZM.

2)HOW TO USE
Keep the directories set up the same way upon extraction. There must be a ZM rom named "zm.gba" in the directory.
Drag the "Arachnus.asm" file on to armips and if set up properly, it will compile and output a rom named "Arachnus.gba"
I also provided a basic room and tileset alongside for a general idea of how its boss arena can look. 

3)Notes
None of Arachnus' projectiles offer drops, so be weary of this when choosing its weaknesses.
Sound effects are as best as I could manage. Same thing with the music. Importing his song is very 
possible, but it isn't worth the effort for me.

4)
I, CaptGlitch, have preformed all of this process myself. I used no$gba for debugging and MAGE for testing.
A large thanks to the developers of these awesome programs. 