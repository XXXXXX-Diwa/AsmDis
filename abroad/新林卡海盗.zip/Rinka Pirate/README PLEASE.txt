Important Note:
Firstly, do not give the Rinka Pirates themselves any sort of drop, or the linked rinka will continue to spawn. 
I could have fixed this, but the rinkas give infinite drops anyway, so why give the pirates any?

HOW TO PATCH:
Keep the directories set up the same way upon extraction. There must be a ZM rom named "zm.gba" in the directory.
Drag the "Rinka Pirate.asm" file on to armips and if set up properly, it will compile and output a rom named "PBPirate.gba"
I also provided a graphics and palette file for the secondary sprite for the rinka pirate.

HOW TO USE:
Rinka Pirates are sprite B6 and it's second sprite (what it holds) is sprite B5. Both if these need to be in the
spriteset. Any rinka that isn't specific to Mother Brain's room will work for the rinka. You need to create the 
sprites in this order to "link" a pirate and rinka: Pirate 1, Rinka 1, Pirate 2, Rinka 2 etc.
These sprites can function independently. In other words, a pirate does not need a rinka to function. It'll
do what it normally does, just without a rinka spawning in it's hands. A rinka not linked to a pirate will
function normally. 